import { createServer } from "node:http";
import { URL } from "node:url";

const PORT = Number(process.env.PORT || 8787);

const historyStore = {
  double: [],
  crash: [],
};

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: {
      "user-agent": "StatEdgeProxy/1.0",
      accept: "application/json",
    },
  });
  if (!response.ok) {
    throw new Error(`Upstream failed: ${response.status}`);
  }
  return response.json();
}

function send(res, status, payload) {
  res.writeHead(status, {
    "content-type": "application/json",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type,authorization",
  });
  res.end(JSON.stringify(payload));
}

function collectBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 2_000_000) {
        reject(new Error("Payload too large"));
      }
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    send(res, 204, {});
    return;
  }

  const url = new URL(req.url || "/", `http://${req.headers.host}`);

  try {
    if (req.method === "GET" && url.pathname === "/health") {
      send(res, 200, { ok: true, service: "statedge-proxy" });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/v1/blaze/roulette/recent") {
      const data = await fetchJson("https://blaze.com/api/roulette_games/recent");
      send(res, 200, data);
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/v1/blaze/crash/recent") {
      const data = await fetchJson("https://blaze.com/api/crash_games/recent");
      send(res, 200, data);
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/v1/ingest") {
      const payload = await collectBody(req);
      const now = new Date().toISOString();

      if (Array.isArray(payload.double)) {
        historyStore.double = [...historyStore.double, ...payload.double.map((row) => ({ ...row, ingestedAt: now }))].slice(-10_000);
      }
      if (Array.isArray(payload.crash)) {
        historyStore.crash = [...historyStore.crash, ...payload.crash.map((row) => ({ ...row, ingestedAt: now }))].slice(-10_000);
      }

      send(res, 202, {
        ok: true,
        stored: {
          double: historyStore.double.length,
          crash: historyStore.crash.length,
        },
      });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/v1/history") {
      send(res, 200, historyStore);
      return;
    }

    send(res, 404, { error: "Not found" });
  } catch (error) {
    send(res, 500, { error: error instanceof Error ? error.message : "Unknown error" });
  }
})
  .listen(PORT, () => {
    console.log(`StatEdge proxy running at http://localhost:${PORT}`);
  });
