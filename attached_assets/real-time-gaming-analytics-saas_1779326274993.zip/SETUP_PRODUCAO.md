# StatEdge Pro - Guia de Montagem

## 1) Rodar o frontend (painel SaaS)

1. Instale dependencias:
   npm install
2. Rode ambiente local:
   npm run dev
3. Abra no navegador:
   http://localhost:5173

## 2) Rodar o backend proxy para Blaze

1. Em outro terminal, inicie:
   node backend/server.mjs
2. O servidor sobe em:
   http://localhost:8787

Esse backend libera CORS, faz proxy para endpoints da Blaze e expoe:
- GET /api/v1/blaze/roulette/recent
- GET /api/v1/blaze/crash/recent
- POST /api/v1/ingest
- GET /api/v1/history
- GET /health

## 3) Conectar frontend no backend

Antes de carregar o app, defina no navegador:

window.__DATA_API_BASE__ = "http://localhost:8787"

Opcao pratica: adicionar em index.html, antes do script principal:

<script>
  window.__DATA_API_BASE__ = "https://SEU_BACKEND";
</script>

## 4) Fluxo de dados real

1. Frontend tenta consumir Blaze via proxy.
2. Se nao houver proxy funcional, app usa simulacao em tempo real.
3. Status aparece em "Fonte de dados" na barra lateral.

## 5) Login, plano e monetizacao (producao)

Recomendado:
- Auth: Supabase Auth (email/senha, magic link)
- Billing: Stripe Checkout + Webhook
- Controle de plano: tabela user_subscriptions no banco
- Feature gate: habilitar modulos por plano (free/pro/elite)

Checklist de deploy vendavel:
- Frontend: Vercel/Netlify
- Backend proxy/API: Railway/Render/Fly.io
- Banco: Supabase Postgres
- Observabilidade: Sentry + logs de API
- LGPD: termos, politica de privacidade, base legal e consentimento

## 6) Aviso de risco e compliance

Este produto deve ser apresentado como leitura estatistica, sem prometer lucro, previsao garantida ou "entradas certas". Inclua aviso legal em telas de sinal e em paginas comerciais.
