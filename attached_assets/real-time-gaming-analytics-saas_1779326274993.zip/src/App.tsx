import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Plan = "free" | "pro" | "elite";
type Color = "red" | "black" | "white";
type Priority = "high" | "medium" | "low";
type Section = "dashboard" | "double" | "crash" | "ia" | "simulator" | "alerts" | "settings";

type DoubleRound = {
  id: number;
  color: Color;
  createdAt: string;
};

type CrashRound = {
  id: number;
  multiplier: number;
  createdAt: string;
};

type AlertItem = {
  id: number;
  priority: Priority;
  title: string;
  text: string;
  createdAt: string;
  read: boolean;
};

type SimulatorResult = {
  strategy: string;
  finalBankroll: number;
  hitRate: number;
  maxDrawdown: number;
  pnl: number;
  curve: number[];
};

const PLAN_FEATURES: Record<Plan, string[]> = {
  free: ["dashboard", "double", "crash", "alerts"],
  pro: ["dashboard", "double", "crash", "alerts", "ia", "simulator"],
  elite: ["dashboard", "double", "crash", "alerts", "ia", "simulator", "api"],
};

const SECTIONS: { id: Section; label: string; required: Plan }[] = [
  { id: "dashboard", label: "Overview", required: "free" },
  { id: "double", label: "Double", required: "free" },
  { id: "crash", label: "Crash", required: "free" },
  { id: "ia", label: "IA Advisor", required: "pro" },
  { id: "simulator", label: "Simulador", required: "pro" },
  { id: "alerts", label: "Alertas", required: "free" },
  { id: "settings", label: "Configuracoes", required: "free" },
];

function randomColor(): Color {
  const r = Math.random();
  if (r < 0.47) return "red";
  if (r < 0.94) return "black";
  return "white";
}

function makeDoubleRounds(count: number): DoubleRound[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    color: randomColor(),
    createdAt: new Date(Date.now() - (count - i) * 22000).toISOString(),
  }));
}

function makeCrashRounds(count: number): CrashRound[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    multiplier: Number((1 + Math.random() * Math.random() * 16).toFixed(2)),
    createdAt: new Date(Date.now() - (count - i) * 18000).toISOString(),
  }));
}

function movingAverage(values: number[], window: number): number {
  if (!values.length) return 0;
  const last = values.slice(-window);
  return last.reduce((acc, n) => acc + n, 0) / last.length;
}

function analyzeDouble(rounds: DoubleRound[]) {
  const recent = rounds.slice(-60);
  const total = recent.length || 1;
  const counts = recent.reduce(
    (acc, cur) => {
      acc[cur.color] += 1;
      return acc;
    },
    { red: 0, black: 0, white: 0 }
  );

  let longestStreak = 1;
  let streak = 1;
  let alternations = 0;
  const patternBreaks: number[] = [];

  for (let i = 1; i < recent.length; i += 1) {
    if (recent[i].color === recent[i - 1].color) {
      streak += 1;
      longestStreak = Math.max(longestStreak, streak);
    } else {
      if (streak >= 4) patternBreaks.push(i);
      streak = 1;
      alternations += 1;
    }
  }

  const alternationRatio = alternations / Math.max(1, recent.length - 1);
  const dominantColor = (Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "red") as Color;
  const dominance = (counts[dominantColor] / total) * 100;
  const whitePressure = counts.white / total;
  const opportunityScore = Math.min(
    100,
    Math.round(30 + dominance * 0.7 + longestStreak * 4 + alternationRatio * 20 - whitePressure * 35)
  );

  return {
    counts,
    longestStreak,
    alternationRatio,
    patternBreaks,
    dominantColor,
    dominance,
    opportunityScore,
  };
}

function analyzeCrash(rounds: CrashRound[]) {
  const recent = rounds.slice(-80);
  const values = recent.map((r) => r.multiplier);
  const maShort = movingAverage(values, 8);
  const maLong = movingAverage(values, 20);
  const highPeaks = values.filter((v) => v >= 10).length;
  const lowBand = values.filter((v) => v < 2).length;
  const volatility = Number((movingAverage(values.map((v) => Math.abs(v - maShort)), 12) || 0).toFixed(2));
  const momentum = maShort - maLong;
  const confidence = Math.max(0, Math.min(100, Math.round(55 + momentum * 8 - volatility * 2 + highPeaks)));

  return {
    maShort,
    maLong,
    highPeaks,
    lowBand,
    volatility,
    momentum,
    confidence,
  };
}

function createDoubleInsight(metrics: ReturnType<typeof analyzeDouble>) {
  const direction = metrics.dominantColor === "red" ? "vermelho" : metrics.dominantColor === "black" ? "preto" : "branco";
  const alternationText = metrics.alternationRatio > 0.55 ? "mercado alternando forte" : "mercado com blocos de repeticao";
  return `Double: ${direction} lidera com ${metrics.dominance.toFixed(1)}% nas ultimas rodadas. ${alternationText}. Score estatistico de oportunidade ${metrics.opportunityScore}/100. Use gerenciamento de banca, sem garantia de acerto.`;
}

function createCrashInsight(metrics: ReturnType<typeof analyzeCrash>) {
  const trend = metrics.maShort > metrics.maLong ? "aceleracao positiva" : "pressao de baixa";
  return `Crash: media curta ${metrics.maShort.toFixed(2)}x contra media longa ${metrics.maLong.toFixed(2)}x. O fluxo atual mostra ${trend}, volatilidade ${metrics.volatility.toFixed(2)} e confianca ${metrics.confidence}/100. Analise historica, nao e previsao garantida.`;
}

async function fetchBlazeDouble(): Promise<DoubleRound[] | null> {
  const apiBase = (globalThis as { __DATA_API_BASE__?: string }).__DATA_API_BASE__ ?? "";
  const sources = [
    `${apiBase}/api/v1/blaze/roulette/recent`,
    "https://blaze.com/api/roulette_games/recent",
  ].filter((url) => url && !url.startsWith("/api") && !url.startsWith("undefined"));

  for (const source of sources) {
    try {
      const res = await fetch(source);
      if (!res.ok) continue;
      const data = (await res.json()) as Array<{ id: number; color: number; created_at?: string }>;
      if (!Array.isArray(data) || !data.length) continue;
      const normalized = data
        .map((item): DoubleRound => ({
          id: Number(item.id),
          color: item.color === 1 ? "red" : item.color === 2 ? "black" : "white",
          createdAt: item.created_at ?? new Date().toISOString(),
        }))
        .reverse();
      return normalized;
    } catch {
      continue;
    }
  }
  return null;
}

async function fetchBlazeCrash(): Promise<CrashRound[] | null> {
  const apiBase = (globalThis as { __DATA_API_BASE__?: string }).__DATA_API_BASE__ ?? "";
  const sources = [
    `${apiBase}/api/v1/blaze/crash/recent`,
    "https://blaze.com/api/crash_games/recent",
  ].filter((url) => url && !url.startsWith("/api") && !url.startsWith("undefined"));

  for (const source of sources) {
    try {
      const res = await fetch(source);
      if (!res.ok) continue;
      const data = (await res.json()) as Array<{ id: number; crash_point?: string | number; created_at?: string }>;
      if (!Array.isArray(data) || !data.length) continue;
      const normalized = data
        .map((item) => ({
          id: Number(item.id),
          multiplier: Number(item.crash_point ?? 1),
          createdAt: item.created_at ?? new Date().toISOString(),
        }))
        .reverse();
      return normalized;
    } catch {
      continue;
    }
  }
  return null;
}

function runSimulator(strategy: string, initialBankroll: number, rounds: DoubleRound[]): SimulatorResult {
  let bankroll = initialBankroll;
  let peak = bankroll;
  let maxDrawdown = 0;
  let stake = initialBankroll * 0.01;
  let wins = 0;
  const curve = [bankroll];

  for (let i = 8; i < rounds.length; i += 1) {
    const sample = rounds.slice(i - 8, i);
    const metrics = analyzeDouble(sample);
    const expected =
      strategy === "Tendencia"
        ? metrics.dominantColor
        : strategy === "Contratendencia"
          ? metrics.dominantColor === "red"
            ? "black"
            : "red"
          : strategy === "Flat"
            ? "red"
            : sample[sample.length - 1].color === "red"
              ? "red"
              : "black";

    const actual = rounds[i].color;
    const isWin = actual === expected;
    if (isWin) {
      bankroll += stake;
      wins += 1;
      if (strategy === "Martingale") stake = Math.max(initialBankroll * 0.01, stake * 0.5);
    } else {
      bankroll -= stake;
      if (strategy === "Martingale") stake = Math.min(initialBankroll * 0.15, stake * 2);
    }
    peak = Math.max(peak, bankroll);
    maxDrawdown = Math.max(maxDrawdown, peak - bankroll);
    curve.push(Number(bankroll.toFixed(2)));
  }

  const pnl = bankroll - initialBankroll;
  return {
    strategy,
    finalBankroll: Number(bankroll.toFixed(2)),
    hitRate: Number(((wins / Math.max(1, rounds.length - 8)) * 100).toFixed(1)),
    maxDrawdown: Number(maxDrawdown.toFixed(2)),
    pnl: Number(pnl.toFixed(2)),
    curve,
  };
}

function Sparkline({ values, positive = true }: { values: number[]; positive?: boolean }) {
  if (!values.length) return null;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const spread = Math.max(1, max - min);
  const points = values
    .map((v, i) => {
      const x = (i / Math.max(1, values.length - 1)) * 100;
      const y = 100 - ((v - min) / spread) * 100;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <svg viewBox="0 0 100 100" className="h-20 w-full">
      <motion.polyline
        fill="none"
        stroke={positive ? "#22d3ee" : "#f43f5e"}
        strokeWidth="3"
        points={points}
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 1.1, ease: "easeOut" }}
      />
    </svg>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState<Section>("dashboard");
  const [plan, setPlan] = useState<Plan>("free");
  const [isLogged, setIsLogged] = useState(false);
  const [email, setEmail] = useState("");
  const [doubleRounds, setDoubleRounds] = useState<DoubleRound[]>(() => makeDoubleRounds(140));
  const [crashRounds, setCrashRounds] = useState<CrashRound[]>(() => makeCrashRounds(140));
  const [source, setSource] = useState<"blaze" | "simulado">("simulado");
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [strategyBankroll, setStrategyBankroll] = useState(1000);
  const [channels, setChannels] = useState({ email: true, push: true, sound: false });

  const doubleMetrics = useMemo(() => analyzeDouble(doubleRounds), [doubleRounds]);
  const crashMetrics = useMemo(() => analyzeCrash(crashRounds), [crashRounds]);

  const simulator = useMemo(() => {
    const strategies = ["Tendencia", "Contratendencia", "Flat", "Martingale"];
    return strategies.map((s) => runSimulator(s, strategyBankroll, doubleRounds.slice(-120)));
  }, [doubleRounds, strategyBankroll]);

  const hasAccess = (section: Section) => {
    const module = section === "settings" ? "dashboard" : section;
    return PLAN_FEATURES[plan].includes(module);
  };

  useEffect(() => {
    let isMounted = true;

    async function bootstrap() {
      const [doubleData, crashData] = await Promise.all([fetchBlazeDouble(), fetchBlazeCrash()]);
      if (!isMounted) return;
      if (doubleData?.length) setDoubleRounds(doubleData.slice(-180));
      if (crashData?.length) setCrashRounds(crashData.slice(-180));
      if (doubleData?.length && crashData?.length) setSource("blaze");
    }
    bootstrap();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (source === "blaze") return;
      setDoubleRounds((prev) => {
        const next = [...prev, { id: prev.length + 1, color: randomColor(), createdAt: new Date().toISOString() }];
        return next.slice(-220);
      });
      setCrashRounds((prev) => {
        const next = [
          ...prev,
          { id: prev.length + 1, multiplier: Number((1 + Math.random() * Math.random() * 18).toFixed(2)), createdAt: new Date().toISOString() },
        ];
        return next.slice(-220);
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [source]);

  useEffect(() => {
    const poll = setInterval(async () => {
      const [doubleData, crashData] = await Promise.all([fetchBlazeDouble(), fetchBlazeCrash()]);
      if (doubleData?.length && crashData?.length) {
        setSource("blaze");
        setDoubleRounds(doubleData.slice(-220));
        setCrashRounds(crashData.slice(-220));
      }
    }, 15000);
    return () => clearInterval(poll);
  }, []);

  useEffect(() => {
    const nextAlerts: AlertItem[] = [];
    if (doubleMetrics.longestStreak >= 6) {
      nextAlerts.push({
        id: Date.now(),
        priority: "high",
        title: "Sequencia longa em Double",
        text: `Foram detectadas ${doubleMetrics.longestStreak} rodadas seguidas. Revise exposicao e risco.`,
        createdAt: new Date().toISOString(),
        read: false,
      });
    }
    if (doubleMetrics.opportunityScore >= 75) {
      nextAlerts.push({
        id: Date.now() + 1,
        priority: "medium",
        title: "Score de oportunidade elevado",
        text: `Double com score ${doubleMetrics.opportunityScore}/100 baseado em distribuicao e ritmo.`,
        createdAt: new Date().toISOString(),
        read: false,
      });
    }
    if (crashMetrics.confidence >= 70) {
      nextAlerts.push({
        id: Date.now() + 2,
        priority: "low",
        title: "Crash em fase estatistica favoravel",
        text: `Confianca ${crashMetrics.confidence}/100 com MA curta acima da longa.`,
        createdAt: new Date().toISOString(),
        read: false,
      });
    }

    if (nextAlerts.length) {
      setAlerts((prev) => [...nextAlerts, ...prev].slice(0, 30));
    }
  }, [doubleMetrics.longestStreak, doubleMetrics.opportunityScore, crashMetrics.confidence]);

  const topSimulator = simulator[0];

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100">
      <div className="flex min-h-screen">
        <aside className="w-64 border-r border-slate-800/80 bg-slate-950/60 p-5">
          <div className="mb-8">
            <p className="text-xs uppercase tracking-[0.2em] text-cyan-400">StatEdge Pro</p>
            <h1 className="mt-1 text-xl font-semibold">Trading Analytics</h1>
            <p className="mt-2 text-xs text-slate-400">Analise estatistica em tempo real para Double e Crash.</p>
          </div>

          <nav className="space-y-1">
            {SECTIONS.map((section) => {
              const locked = !hasAccess(section.id);
              const active = activeSection === section.id;
              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`relative w-full rounded-md px-3 py-2 text-left text-sm transition ${
                    active ? "text-white" : "text-slate-400 hover:text-slate-100"
                  }`}
                >
                  {active && <motion.span layoutId="activeSection" className="absolute inset-0 rounded-md bg-cyan-500/10" />}
                  <span className="relative z-10 flex items-center justify-between">
                    {section.label}
                    {locked ? <span className="text-[10px] uppercase text-amber-400">locked</span> : null}
                  </span>
                </button>
              );
            })}
          </nav>

          <div className="mt-8 border-t border-slate-800 pt-4 text-xs text-slate-400">
            <p>Plano atual: {plan.toUpperCase()}</p>
            <p>Fonte de dados: {source === "blaze" ? "Blaze live/proxy" : "Simulada"}</p>
            <p className="mt-2 text-slate-500">Sem promessa de ganho. Sistema focado em leitura estatistica.</p>
          </div>
        </aside>

        <main className="flex-1 p-6 lg:p-8">
          <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-5">
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-cyan-400">SaaS Premium</p>
              <h2 className="text-2xl font-semibold">Operacao em tempo real</h2>
            </div>
            <div className="flex items-center gap-2 text-sm">
              {!isLogged ? (
                <button
                  onClick={() => setIsLogged(true)}
                  className="rounded-md bg-cyan-500 px-3 py-2 font-medium text-slate-950 transition hover:bg-cyan-400"
                >
                  Login rapido
                </button>
              ) : (
                <>
                  <span className="rounded-md border border-slate-700 px-3 py-2 text-slate-300">{email || "user@statedge.ai"}</span>
                  <button
                    onClick={() => {
                      setIsLogged(false);
                      setEmail("");
                    }}
                    className="rounded-md border border-slate-700 px-3 py-2 text-slate-300"
                  >
                    Sair
                  </button>
                </>
              )}
            </div>
          </header>

          <AnimatePresence mode="wait">
            <motion.section
              key={activeSection}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
            >
              {!hasAccess(activeSection) ? (
                <div className="rounded-lg border border-amber-500/40 bg-amber-500/5 p-6">
                  <h3 className="text-lg font-semibold text-amber-300">Recurso premium bloqueado</h3>
                  <p className="mt-2 max-w-3xl text-sm text-slate-300">
                    Este modulo requer plano {activeSection === "ia" || activeSection === "simulator" ? "PRO" : "ELITE"}. Em producao,
                    conecte com Stripe para upgrade automatico e Supabase/Auth0 para gerenciamento de sessao.
                  </p>
                </div>
              ) : activeSection === "dashboard" ? (
                <div className="space-y-7">
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-xs text-slate-400">Double score</p>
                      <p className="mt-2 text-3xl font-semibold text-cyan-300">{doubleMetrics.opportunityScore}</p>
                      <p className="mt-2 text-xs text-slate-500">Com base em frequencia, alternancia e sequencias recentes.</p>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-xs text-slate-400">Crash confianca</p>
                      <p className="mt-2 text-3xl font-semibold text-fuchsia-300">{crashMetrics.confidence}</p>
                      <p className="mt-2 text-xs text-slate-500">Leitura estatistica de medias moveis e volatilidade.</p>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-xs text-slate-400">Melhor estrategia (simulador)</p>
                      <p className="mt-2 text-xl font-semibold">{topSimulator.strategy}</p>
                      <p className={`mt-2 text-sm ${topSimulator.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                        PnL {topSimulator.pnl >= 0 ? "+" : ""}
                        {topSimulator.pnl.toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-6 lg:grid-cols-2">
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-sm font-medium">Insight Double</p>
                      <p className="mt-3 text-sm leading-6 text-slate-300">{createDoubleInsight(doubleMetrics)}</p>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-sm font-medium">Insight Crash</p>
                      <p className="mt-3 text-sm leading-6 text-slate-300">{createCrashInsight(crashMetrics)}</p>
                    </div>
                  </div>

                  <div className="grid gap-6 lg:grid-cols-2">
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="mb-3 text-sm font-medium">Historico Double (ultimas 36)</p>
                      <div className="flex flex-wrap gap-2">
                        {doubleRounds.slice(-36).map((round) => (
                          <span
                            key={round.id}
                            className={`h-4 w-4 rounded-full ${
                              round.color === "red"
                                ? "bg-rose-500"
                                : round.color === "black"
                                  ? "bg-slate-200"
                                  : "bg-violet-500"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="mb-3 text-sm font-medium">Curva media de multiplicadores</p>
                      <Sparkline values={crashRounds.slice(-40).map((x) => x.multiplier)} positive={crashMetrics.momentum >= 0} />
                    </div>
                  </div>
                </div>
              ) : activeSection === "double" ? (
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-4">
                    {(["red", "black", "white"] as Color[]).map((color) => (
                      <div key={color} className="rounded-lg border border-slate-800 bg-slate-900/30 p-4">
                        <p className="text-xs uppercase text-slate-400">{color}</p>
                        <p className="mt-2 text-2xl font-semibold">{doubleMetrics.counts[color]}</p>
                      </div>
                    ))}
                    <div className="rounded-lg border border-cyan-600/40 bg-cyan-500/5 p-4">
                      <p className="text-xs uppercase text-cyan-300">Score oportunidade</p>
                      <p className="mt-2 text-2xl font-semibold text-cyan-200">{doubleMetrics.opportunityScore}/100</p>
                    </div>
                  </div>

                  <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                    <p className="text-sm font-medium">Tabela recente com padroes detectados</p>
                    <div className="mt-3 overflow-x-auto">
                      <table className="w-full min-w-[680px] text-left text-sm">
                        <thead className="text-xs text-slate-400">
                          <tr>
                            <th className="pb-2">ID</th>
                            <th className="pb-2">Cor</th>
                            <th className="pb-2">Horario</th>
                            <th className="pb-2">Padrao</th>
                          </tr>
                        </thead>
                        <tbody className="text-slate-200">
                          {doubleRounds
                            .slice(-18)
                            .reverse()
                            .map((round, idx, arr) => {
                              const prev = arr[idx + 1];
                              const pattern = !prev
                                ? "inicio"
                                : prev.color === round.color
                                  ? "sequencia"
                                  : idx % 2 === 0
                                    ? "alternancia"
                                    : "quebra";
                              return (
                                <tr key={round.id} className="border-t border-slate-800/70">
                                  <td className="py-2">#{round.id}</td>
                                  <td className="py-2 uppercase">{round.color}</td>
                                  <td className="py-2">{new Date(round.createdAt).toLocaleTimeString("pt-BR")}</td>
                                  <td className="py-2">{pattern}</td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : activeSection === "crash" ? (
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-4">
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-xs text-slate-400">Media curta</p>
                      <p className="mt-2 text-2xl font-semibold">{crashMetrics.maShort.toFixed(2)}x</p>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-xs text-slate-400">Media longa</p>
                      <p className="mt-2 text-2xl font-semibold">{crashMetrics.maLong.toFixed(2)}x</p>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                      <p className="text-xs text-slate-400">Picos &gt;= 10x</p>
                      <p className="mt-2 text-2xl font-semibold">{crashMetrics.highPeaks}</p>
                    </div>
                    <div className="rounded-lg border border-fuchsia-500/40 bg-fuchsia-500/5 p-4">
                      <p className="text-xs text-fuchsia-300">Confianca</p>
                      <p className="mt-2 text-2xl font-semibold text-fuchsia-200">{crashMetrics.confidence}/100</p>
                    </div>
                  </div>

                  <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                    <p className="mb-3 text-sm font-medium">Multiplicadores recentes</p>
                    <Sparkline values={crashRounds.slice(-60).map((x) => x.multiplier)} positive={crashMetrics.momentum >= 0} />
                    <div className="mt-3 grid grid-cols-3 gap-2 text-xs text-slate-400">
                      <p>Faixa baixa (&lt; 2x): {crashMetrics.lowBand}</p>
                      <p>Volatilidade: {crashMetrics.volatility}</p>
                      <p>Ciclo: {crashMetrics.momentum >= 0 ? "Expansao" : "Contracao"}</p>
                    </div>
                  </div>
                </div>
              ) : activeSection === "ia" ? (
                <div className="space-y-6">
                  <div className="rounded-lg border border-cyan-500/35 bg-cyan-500/5 p-5">
                    <p className="text-sm font-semibold text-cyan-300">IA Advisor - Double</p>
                    <p className="mt-3 text-sm leading-6 text-slate-200">{createDoubleInsight(doubleMetrics)}</p>
                    <p className="mt-4 text-xs text-slate-400">
                      Probabilidade calculada por frequencia, sequencia e alternancia. Nao representa certeza de resultado.
                    </p>
                  </div>
                  <div className="rounded-lg border border-fuchsia-500/35 bg-fuchsia-500/5 p-5">
                    <p className="text-sm font-semibold text-fuchsia-300">IA Advisor - Crash</p>
                    <p className="mt-3 text-sm leading-6 text-slate-200">{createCrashInsight(crashMetrics)}</p>
                    <p className="mt-4 text-xs text-slate-400">Modelo orientado a comportamento recente, ciclos e medias moveis.</p>
                  </div>
                </div>
              ) : activeSection === "simulator" ? (
                <div className="space-y-6">
                  <div className="rounded-lg border border-slate-800 bg-slate-900/35 p-4">
                    <label className="text-sm text-slate-300">Banca inicial para teste</label>
                    <div className="mt-2 flex items-center gap-3">
                      <input
                        type="number"
                        min={100}
                        step={100}
                        value={strategyBankroll}
                        onChange={(e) => setStrategyBankroll(Number(e.target.value))}
                        className="w-44 rounded-md border border-slate-700 bg-slate-900 px-3 py-2 outline-none ring-cyan-400 focus:ring"
                      />
                      <span className="text-xs text-slate-500">Compara 4 estrategias usando historico recente.</span>
                    </div>
                  </div>
                  <div className="grid gap-4 lg:grid-cols-2">
                    {simulator.map((item) => (
                      <motion.div
                        key={item.strategy}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="rounded-lg border border-slate-800 bg-slate-900/30 p-4"
                      >
                        <p className="font-medium">{item.strategy}</p>
                        <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-400">
                          <p>Banca final: {item.finalBankroll.toFixed(2)}</p>
                          <p>Hit rate: {item.hitRate}%</p>
                          <p>Max drawdown: {item.maxDrawdown.toFixed(2)}</p>
                          <p className={item.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}>PnL: {item.pnl.toFixed(2)}</p>
                        </div>
                        <div className="mt-3">
                          <Sparkline values={item.curve.slice(-40)} positive={item.pnl >= 0} />
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              ) : activeSection === "alerts" ? (
                <div className="space-y-4">
                  <div className="rounded-lg border border-slate-800 bg-slate-900/30 p-4">
                    <p className="text-sm text-slate-300">Canais de alerta</p>
                    <div className="mt-3 flex flex-wrap gap-3">
                      {Object.keys(channels).map((key) => (
                        <label key={key} className="flex items-center gap-2 text-sm text-slate-300">
                          <input
                            type="checkbox"
                            checked={channels[key as keyof typeof channels]}
                            onChange={() =>
                              setChannels((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }))
                            }
                          />
                          {key}
                        </label>
                      ))}
                    </div>
                  </div>
                  {alerts.length === 0 ? (
                    <p className="text-sm text-slate-400">Sem alertas no momento.</p>
                  ) : (
                    alerts.map((alert) => (
                      <div key={alert.id} className="rounded-lg border border-slate-800 bg-slate-900/25 p-4">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-medium">{alert.title}</p>
                          <span
                            className={`rounded px-2 py-1 text-xs uppercase ${
                              alert.priority === "high"
                                ? "bg-rose-500/15 text-rose-300"
                                : alert.priority === "medium"
                                  ? "bg-amber-500/15 text-amber-300"
                                  : "bg-cyan-500/15 text-cyan-300"
                            }`}
                          >
                            {alert.priority}
                          </span>
                        </div>
                        <p className="mt-2 text-sm text-slate-300">{alert.text}</p>
                        <button
                          onClick={() => setAlerts((prev) => prev.map((a) => (a.id === alert.id ? { ...a, read: true } : a)))}
                          className="mt-3 text-xs text-cyan-300 hover:text-cyan-200"
                        >
                          Marcar como lido
                        </button>
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="rounded-lg border border-slate-800 bg-slate-900/30 p-5">
                    <p className="text-sm font-semibold">Conta e planos</p>
                    <div className="mt-4 flex flex-wrap gap-3">
                      {(["free", "pro", "elite"] as Plan[]).map((itemPlan) => (
                        <button
                          key={itemPlan}
                          onClick={() => setPlan(itemPlan)}
                          className={`rounded-md px-4 py-2 text-sm font-medium ${
                            plan === itemPlan
                              ? "bg-cyan-500 text-slate-950"
                              : "border border-slate-700 text-slate-200 hover:bg-slate-800"
                          }`}
                        >
                          {itemPlan.toUpperCase()}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-lg border border-slate-800 bg-slate-900/30 p-5">
                    <p className="text-sm font-semibold">Integracao backend (pronto para producao)</p>
                    <ul className="mt-3 space-y-2 text-sm text-slate-300">
                      <li>Endpoint de ingestao: POST /api/v1/ingest</li>
                      <li>Proxy esperado: GET /api/v1/blaze/roulette/recent e /api/v1/blaze/crash/recent</li>
                      <li>Autenticacao recomendada: Supabase Auth ou Auth0</li>
                      <li>Assinatura: Stripe Checkout com webhook para upgrade de plano</li>
                    </ul>
                  </div>

                  <div className="rounded-lg border border-rose-500/40 bg-rose-500/5 p-5 text-sm text-rose-100">
                    Aviso de risco: esta plataforma nao oferece garantia de lucro. Os sinais sao estatisticos e descritivos.
                  </div>

                  {!isLogged && (
                    <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-5">
                      <p className="text-sm font-medium">Login demonstrativo</p>
                      <div className="mt-3 flex flex-wrap items-center gap-3">
                        <input
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="seu-email@dominio.com"
                          className="w-64 rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm outline-none ring-cyan-400 focus:ring"
                        />
                        <button
                          onClick={() => setIsLogged(true)}
                          className="rounded-md bg-cyan-500 px-4 py-2 text-sm font-medium text-slate-950"
                        >
                          Entrar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </motion.section>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
